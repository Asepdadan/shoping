<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$route['default_controller'] = 'home';


/*admin*/
$route['login'] = 'root/Login/index';
$route['check_login'] = 'root/Login/aksi_login';
$route['dashbord'] = 'root/Produk';
$route['logout'] = 'root/Login/logout';
//$route['home'] = 'root/Produk';
$route['tambah'] = 'root/produk/index';




$route['add'] = 'root/produk/tambah_produk';
$route['edit'] = 'root/produk/actionEdit';
//$route['detail/:num'] = 'home/produk_Detail/id';


//kategori pria
$route['pria'] = 'kategori/pria';
$route['celana-pria'] = 'kategori/pria_celana';
$route['kemeja-pria'] = 'kategori/pria_kemeja';
$route['blazer-pria'] = 'kategori/pria_blazer';
$route['topi-pria'] = 'kategori/pria_topi';
$route['jaket-pria'] = 'kategori/pria_jaket';
$route['kategori/batas_harga'] = 'kategori';


//kategori wanita
$route['wanita'] = 'kategori/wanita';
$route['celana-wanita'] = 'kategori/wanita_celana';
$route['kemeja-wanita'] = 'kategori/wanita_kemeja';
$route['atasan-wanita'] = 'kategori/wanita_atasa';
$route['kaos-wanita'] = 'kategori/wanita_kaos';
$route['kerudung-wanita'] = 'kategori/wanita_kerudung';
$route['sendal-wanita'] = 'kategori/wanita_sendal';
$route['gamis-wanita'] = 'kategori/wanita_gamis';
$route['jaket-wanita'] = 'kategori/wanita_jaket';


$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
