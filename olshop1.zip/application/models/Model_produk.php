<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_produk extends CI_Model {

    public function getPag($num,$offset){
        $this->db->order_by('created','DESC');
        $data = $this->db->get('tbl_produk',$num,$offset);
      
        return $data->result_array();

    }

    public function getpencarian($keywoard){
    return $this->db->query("select * from tbl_produk where nama like '%$keywoard%'")->result_array();        
    }

    public function getProduk(){
      return  $this->db->query("SELECT * FROM `tbl_produk` ORDER BY RAND()")->result_array();
    }    
/*    Order by created DESC Limit 100 */

    public function getdata(){
      return  $this->db->query("SELECT * FROM `tbl_produk` Order by created DESC Limit 9 ")->result_array();
    }

    public function getDatawhere($id){
        return $this->db->query("select * from tbl_produk where id = $id limit 1")->result_array();
    }
    
    public function hitungStok(){
        return $this->db->query("SELECT COUNT(DISTINCT id) FROM `tbl_produk` WHERE stok > 0")->result_array();
    }
 
    public function addProduk($tablename,$data){
        $this->db->insert($tablename,$data);
    }

    public function getKategori($tablename){
        return $this->db->get($tablename)->result_array();

    }


    //kategori pria
     public function getKategoripria(){
        return $this->db->query("SELECT * from `tbl_produk` where LEFT(kategori_id,1) = 'P' ORDER BY created DESC")->result_array();
    }

    public function getpriaCelana(){
    return $this->db->query("SELECT * FROM `tbl_produk` WHERE kategori_id = 'P001' ORDER BY created")->result_array();
    }

    public function getpriaKemeja(){
    return $this->db->query("SELECT * FROM `tbl_produk` WHERE kategori_id = 'P002' ORDER BY created")->result_array();
    }

    public function getpriaBlazer(){
    return $this->db->query("SELECT * FROM `tbl_produk` WHERE kategori_id = 'P003' ORDER BY created")->result_array();
    }

    public function getpriaKaos(){
    return $this->db->query("SELECT * FROM `tbl_produk` WHERE kategori_id = 'P004' ORDER BY created")->result_array();
    }

    public function getpriaTopi(){
    return $this->db->query("SELECT * FROM `tbl_produk` WHERE kategori_id = 'P005' ORDER BY created")->result_array();
    }

    public function getpriaJaket(){
    return $this->db->query("SELECT * FROM `tbl_produk` WHERE kategori_id = 'P006' ORDER BY created")->result_array();
    }




// query kategori wanita
     public function getKategoriwanita(){
        return $this->db->query("SELECT * from `tbl_produk` where LEFT(kategori_id,1) = 'W' ORDER BY created")->result_array();

    }

    public function getwanitaCelana(){
    return $this->db->query("SELECT * FROM `tbl_produk` WHERE kategori_id = 'W001' ORDER BY created")->result_array();
    }

    public function getwanitaGamis(){
    return $this->db->query("SELECT * FROM `tbl_produk` WHERE kategori_id = 'W002' ORDER BY created")->result_array();
    }

    public function getwanitaJaket(){
    return $this->db->query("SELECT * FROM `tbl_produk` WHERE kategori_id = 'W003' ORDER BY created")->result_array();
    }

    public function getwanitaAtasan(){
    return $this->db->query("SELECT * FROM `tbl_produk` WHERE kategori_id = 'W004' ORDER BY created")->result_array();
    }

    public function getwanitaSendal(){
    return $this->db->query("SELECT * FROM `tbl_produk` WHERE kategori_id = 'W005' ORDER BY created")->result_array();
    }

    public function getwanitaKerudung(){
    return $this->db->query("SELECT * FROM `tbl_produk` WHERE kategori_id = 'W006' ORDER BY created")->result_array();
    }

    public function getwanitaKaos(){
    return $this->db->query("SELECT * FROM `tbl_produk` WHERE kategori_id = 'W007' ORDER BY created")->result_array();
    }

    public function getwanitaKameja(){
    return $this->db->query("SELECT * FROM `tbl_produk` WHERE kategori_id = 'W008' ORDER BY created")->result_array();
    }

    //hapus produk
    public function getWhere($id){
        return $this->db->query("select * from tbl_produk where id = $id")->result_array();
    }
    public function hapusProduk($id){
        $this->db->query("delete from tbl_produk where id = $id ");
    }
    public function showForm($id){
        return $this->db->query("select * from tbl_produk where id = $id limit 1")->result_array();
    }

    public function edit($tablename,$data,$where){
        $this->db->update($tablename,$data,$where);
    }


    public function login($email,$password){
        return $this->db->query("select email,password from tbl_admin where email = '$email' and password = '$password' ")->result_array();
    }


}
