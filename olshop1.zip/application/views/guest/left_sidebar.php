  <!-- like fb -->
  <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v2.5&appId=1077278998952020";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- comment fb -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v2.5&appId=1077278998952020";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>


    <section>
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="left-sidebar">
                        <h2>Kategori</h2>
                        <div class="panel-group category-products" id="accordian"><!--category-productsr-->
                            
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" data-parent="#accordian" href="#mens">
                                            <span class="badge pull-right"><i class="fa fa-plus"></i></span>
                                            Pria
                                        </a>
                                    </h4>
                                </div>
                                <div id="mens" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <ul>
                                            <li><a href="<?php echo base_url().'pria'; ?>">All</a></li>
                                            <li><a href="<?php echo base_url().'blazer-pria'; ?>">Blazer</a></li>
                                            <li><a href="<?php echo base_url().'celana-pria'; ?>">Celana</a></li>
                                            <li><a href="<?php echo base_url().'jaket-pria'; ?>">Jaket</a></li>
                                            <li><a href="<?php echo base_url().'kemeja-pria'; ?>">Kemeja</a></li>
                                            <li><a href="<?php echo base_url().'kaos-pria'; ?>">Kaos</a></li>
                                            <li><a href="<?php echo base_url().'topi-pria'; ?>">Topi</a></li>                                          
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" data-parent="#accordian" href="#womens">
                                            <span class="badge pull-right"><i class="fa fa-plus"></i></span>
                                            Wanita
                                        </a>
                                    </h4>
                                </div>
                                <div id="womens" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <ul>
                                            <li><a href="<?php echo base_url().'wanita'; ?>">All</a></li>
                                            <li><a href="<?php echo base_url().'sendal-wanita'; ?>">Sendal Sepatu</a></li>
                                            <li><a href="<?php echo base_url().'jaket-wanita'; ?>">Jaket</a></li>
                                            <li><a href="<?php echo base_url().'atasan-wanita'; ?>">Atasan</a></li>
                                            <li><a href="<?php echo base_url().'kerudung-wanita'; ?>">Kerudung</a></li>
                                            <li><a href="<?php echo base_url().'kemeja-wanita'; ?>">Kemeja</a></li>
                                            <li><a href="<?php echo base_url().'gamis-wanita'; ?>">Hijab</a></li>
                                            <li><a href="<?php echo base_url().'celana-wanita'; ?>">Celana</a></li>
                                            <li><a href="<?php echo base_url().'kaos-wanita'; ?>">Kaos</a></li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title"><a href="#">Kids</a></h4>
                                </div>
                            </div>
                            
                        </div><!--/category-products-->
                        
                      

                       <!-- <div class="panel panel-warning" >
                            <div class="panel-heading" style="background: #0EB3F6; color:white; text-align:center;">
                                <h3 class="panel-title">Sukai Dan Bagikan</h3>
                            </div>
                            <div class="panel-body">
                               Sukai Jika anda suka dengan halam informasi ini dan bagikan jika ingin teman anda dapat mengetahui
                               <div class="fb-like" data-href="http://gudangjeansfashion.com/" data-layout="box_count" data-action="like" data-show-faces="true" data-share="true"></div>
                            </div>
                        </div>-->

                    <div class="panel panel-warning" >
                            <div class="panel-heading" style="background: #0EB3F6; color:white; text-align:center;">
                                <h3 class="panel-title">Pengunjung</h3>
                            </div>
                            <div class="panel-body">
                               
                            
                                <!-- Histats.com  START  (standard)-->
                                <script type="text/javascript">document.write(unescape("%3Cscript src=%27http://s10.histats.com/js15.js%27 type=%27text/javascript%27%3E%3C/script%3E"));</script>
                                <a href="http://www.histats.com" target="_blank" title="" ><script  type="text/javascript" >
                                try {Histats.start(1,3349234,4,402,118,80,"00011111");
                                Histats.track_hits();} catch(err){};
                                </script></a>
                                <noscript><a href="http://www.histats.com" target="_blank"><img  src="http://sstatic1.histats.com/0.gif?3349234&101" alt="" border="0"></a></noscript>
                                <!-- Histats.com  END  -->
                                
                            </div>
                        </div>


                    
                    </div>
                </div>  