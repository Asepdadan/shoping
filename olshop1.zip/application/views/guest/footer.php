    <div class="footer-widget">
            <div class="container">
                <div class="row">
  
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <p class="pull-left">Copyright © 2016 </p>
                    <p class="pull-right">Designed by <span><a target="_blank" href="#">Asep Dadan</a></span></p>
                </div>
            </div>
        </div>
        
    </footer><!--/Footer-->
    

  
    <script src="<?php echo base_url()?>assets/js/jquery.js"></script>
    <script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/jquery.scrollUp.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/price-range.js"></script>
    <script src="<?php echo base_url()?>assets/js/jquery.prettyPhoto.js"></script>
    <script src="<?php echo base_url()?>assets/js/main.js"></script>
</body>
</html>