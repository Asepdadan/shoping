<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

        function __construct()
        {
        parent::__construct();

        $this->load->model('Model_produk');
        $this->load->helper(array('form', 'url','help'));      
        }

    public function index($id=Null)
    {


        $config['base_url'] = 'http://localhost/olshop/home/index';
        $config['total_rows'] = $this->db->get('tbl_produk')->num_rows();
        $config['per_page'] = 25;
        $config['first_page'] = 'Awal';
         $config['last_page'] = 'Akhir';
         $config['next_page'] = '&laquo;';
         $config['prev_page'] = '&raquo;';

        $this->pagination->initialize($config);


        $data['halaman'] = $this->pagination->create_links();
        $data['data'] = $this->Model_produk->getPag($config['per_page'], $id);
        
        
        $data['title'] = "Home";
        
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/content',$data);
        $this->load->view('guest/footer');
    }

    public function produk_Detail($id){

        $data['data'] = $this->Model_produk->getDatawhere($id);
        $data['share'] = base_url().'home/produk_Detail/'.$id;
        $data['title'] = "Produk Detail";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/produk_detail',$data);
        
        
    }

    public function pencarian(){
        $pencarian = $this->input->post('pencarian');
        $data['title'] = "Pencarian";
        $data['data'] = $this->Model_produk->getpencarian($pencarian);
         $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/pencarian',$data);
        $this->load->view('guest/footer');
        
    }

    public function test(){
        $this->load->view('guest/header');
        $this->load->view('test-cart');
        $this->load->view('guest/footer');
    }






}
