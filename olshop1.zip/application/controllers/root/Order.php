<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {

        function __construct()
        {
            parent::__construct();

            $this->load->model('Model_produk');
            $this->load->helper(array('form', 'url','help'));
              $this->load->library('image_lib');
             $this->load->library('form_validation');
        }

        public function index(){


        }

        public function order(){
            print_r($_POST);

        }


    }