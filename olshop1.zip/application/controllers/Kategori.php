<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kategori extends CI_Controller {

        function __construct()
        {
            parent::__construct();

            $this->load->model('Model_produk');
            $this->load->helper(array('form', 'url'));
             //$this->load->library('form_validation');
            $this->load->library('pagination');

        }

        public function index($id=NULL){
            

        $config['base_url'] = 'http://localhost/olshop/kategori/index';
        $config['total_rows'] = $this->db->get('tbl_produk')->num_rows();
        $config['per_page'] = 6;
        $config['first_page'] = 'Awal';
         $config['last_page'] = 'Akhir';
         $config['next_page'] = '&laquo;';
         $config['prev_page'] = '&raquo;';

        $this->pagination->initialize($config);


        $data['halaman'] = $this->pagination->create_links();
        $data['data'] = $this->Model_produk->getPag($config['per_page'], $id);

        $data['title'] = "Kategori";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }

        public function pria($id=NULL){
        /*$config['base_url'] = 'http://localhost/olshop/kategori/pria/';
        $config['total_rows'] = $this->db->get('tbl_produk')->num_rows();
        $config['per_page'] = 6;
        $config['first_page'] = 'Awal';
         $config['last_page'] = 'Akhir';
         $config['next_page'] = '&laquo;';
         $config['prev_page'] = '&raquo;';

        $this->pagination->initialize($config);


        $data['halaman'] = $this->pagination->create_links();
        $data['data'] = $this->Model_produk->getKategoripria($config['per_page']); */
        //$data['data'] = $this->Model_produk->getKategoripria(); 
          
        $data['data'] = $this->Model_produk->getKategoripria();
        $data['title'] = "Kategori Pria";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }

        public function pria_celana(){
        $data['data'] = $this->Model_produk->getpriaCelana();
        $data['title'] = "Kategori Celana Pria";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }

        public function pria_kemeja(){
        $data['data'] = $this->Model_produk->getpriaKemeja();
        $data['title'] = "Kategori Kemeja Pria";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }

        public function pria_blazer(){
        $data['data'] = $this->Model_produk->getpriaBlazer();
        $data['title'] = "Kategori Blazer Pria";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }

         public function pria_kaos(){
        $data['data'] = $this->Model_produk->getpriaKaos();
        $data['title'] = "Kategori Kaos Pria";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }

        public function pria_topi(){
        $data['data'] = $this->Model_produk->getpriaTopi();
        $data['title'] = "Kategori Topi Pria";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }

        public function pria_jaket(){
        $data['data'] = $this->Model_produk->getpriaJaket();
        $data['title'] = "Kategori Jaket Pria";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }



        //kategori wanita
        public function wanita(){
        $data['data'] = $this->Model_produk->getKategoriwanita();
        $data['title'] = "Kategori Wanita";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');


        }

        public function wanita_celana(){
        $data['data'] = $this->Model_produk->getwanitaCelana();
        $data['title'] = "Kategori Celana Wanita";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }


        public function wanita_gamis(){
        $data['data'] = $this->Model_produk->getwanitaGamis();
        $data['title'] = "Kategori Gamis Wanita";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }



        public function wanita_jaket(){
        $data['data'] = $this->Model_produk->getwanitaJaket();
        $data['title'] = "Kategori Jaket Wanita";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }


       
        public function wanita_atasan(){
        $data['data'] = $this->Model_produk->getwanitaAtasan();
        $data['title'] = "Kategori Atasan Wanita";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }


        public function wanita_sendal(){
        $data['data'] = $this->Model_produk->getwanitaSendal();
        $data['title'] = "Kategori Senda Sepatu Wanita";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }


        public function wanita_kerudung(){
        $data['data'] = $this->Model_produk->getwanitaKerudung();
        $data['title'] = "Kategori Kerudung Wanita";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }

        public function wanita_kaos(){
        $data['data'] = $this->Model_produk->getwanitaKaos();
        $data['title'] = "Kategori Kaos Wanita";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }

        public function wanita_kemeja(){
        $data['data'] = $this->Model_produk->getwanitaKameja();
        $data['title'] = "Kategori Kemeja Wanita";
        $this->load->view('guest/header',$data);
        $this->load->view('guest/menu');
        $this->load->view('guest/slider');
        $this->load->view('guest/left_sidebar');
        $this->load->view('guest/kategori',$data);
        $this->load->view('guest/footer');

        }








        public function batas_harga(){

            $harga = $_POST['harga'];
            $data = $this->db->query("select * from tbl_produk where harga <= $harga")->result_array();           
                        
        }

}